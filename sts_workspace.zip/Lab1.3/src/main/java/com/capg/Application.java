package com.capg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
ApplicationContext context = new ClassPathXmlApplicationContext("Spring.xml");
		
		SBU sbu=context.getBean("sbu", SBU.class);

		// Get Bean of Type Employee AND ID emp
		Employee emp1 = context.getBean("emp1", Employee.class);
		Employee emp2 = context.getBean("emp2", Employee.class);
		// Get Bean with ID emp, but DON'T assign Type
		

		System.out.println("SBU Details");
		System.out.println("-------------------------------------------");
		System.out.println(sbu.toString());
		
	}

}
