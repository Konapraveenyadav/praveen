package com.capg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(Application.class, args);
		SBU sbu = context.getBean(SBU.class);
		sbu.setSbuId(1);
		sbu.setSbuName("Product Engineering Services");
		sbu.setSbuHead("Kiran rao");

		// Get Bean of Type Employee AND ID emp
		Employee emp = context.getBean(Employee.class);
		emp.setEmployeeId(12345);
		emp.setEmployeeName("Harriet");
		emp.setSalary(40000);
		emp.setBusinessUnit(sbu);
		emp.setAge(30);

		// Get Bean with ID emp, but DON'T assign Type
		System.out.println(emp.getEmployeeId());
		emp.getSalary();
		emp.getAge();
		sbu.getSbuId();
		sbu.getSbuName();
		sbu.getSbuHead();
		emp.getBusinessUnit();

		System.out.println("Employee Details");
		System.out.println("-------------------------------------------");
		System.out.println(emp);

	}

}
