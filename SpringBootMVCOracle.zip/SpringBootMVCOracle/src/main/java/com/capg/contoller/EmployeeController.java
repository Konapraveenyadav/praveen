package com.capg.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.capg.beans.Employee;
import com.capg.exception.EmployeeExp;
import com.capg.service.IEmployeeService;
@Controller
//@RestController
public class EmployeeController {
	
	@Autowired
	IEmployeeService service;
		
	@GetMapping(path="/employee/{eid}")
	public Employee getEmployeeById(@PathVariable int eid) 
	//public void deleteEmployeeById(@PathVariable int eid)
	{
		
	Employee emp =	service.getEmployeeById(eid);
		//service.deleteEmployeeById(eid);
		
		
		return emp;
		}
	@GetMapping("/employees")
	public List<Employee> getAllEmployee() {
		
 return service.getAllEmployee();
		
		
	}
	@PostMapping(path="/employee",consumes="application/json")
	public Employee addEmployee(@RequestBody Employee emp) {
	return	service.addEmployee(emp);
		
	}
	@PutMapping(path="/employee",consumes="application/json")
	public Employee updateEmployee(@RequestBody Employee emp) {
		return service.UpdateEmployee(emp);
	}
	@GetMapping(path="/employeesalary/{salary}")
	public List<Employee> getEmployeeBySalary(@PathVariable double salary) throws EmployeeExp 
	
	{
		
	List<Employee> list =	service.getEmployeeBySalary(salary);
		if(list.size() == 0)
			throw new EmployeeExp();
		else
		
		
		return list;
		}
	/*@GetMapping(path="/employeerange")
	public List<Employee> getEmployeeByRange(@PathVariable double salary) 
	{
		List<Employee> list =	service.getEmployeeByRange(salary);
		return list;
		}*/
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Employee not found")
	@ExceptionHandler( {EmployeeExp.class})
	public void handleException() {
		
	}
}
