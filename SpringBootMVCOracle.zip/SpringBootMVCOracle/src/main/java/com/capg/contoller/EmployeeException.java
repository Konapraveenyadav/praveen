package com.capg.contoller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.capg.beans.ErrorInfo;
import com.capg.exception.EmployeeExp;

@ControllerAdvice
public class EmployeeException {
@ResponseStatus(value = HttpStatus.NOT_FOUND,reason="Employee id doesnt exist")
@ExceptionHandler(value ={EmployeeExp.class})
protected ErrorInfo handleException(Exception ex,HttpServletRequest req) {
	String bodyOfResponse =ex.getMessage();
	String uri = req.getRequestURL().toString();
	return new ErrorInfo(uri,bodyOfResponse);
}
}
