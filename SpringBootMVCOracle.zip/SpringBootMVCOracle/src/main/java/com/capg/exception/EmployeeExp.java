package com.capg.exception;

import org.springframework.stereotype.Controller;

@Controller
public class EmployeeExp extends Exception {

}
